from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html', apples=None, people=None, apples_per_person=None,
                           remaining_apples=None, apples_per_person_half=None, remaining_apples_half=None)

@app.route('/result', methods=['POST'])
def result():
    try:
        apples = int(request.form['apples'])
        people = int(request.form['people'])

        if people == 0:
            return render_template('index.html', error="Нельзя делить на ноль!")

        # расчет для целых яблок
        apples_per_person = apples // people
        remaining_apples = apples % people
        
        # расчет с делением на половинки
        apples_per_person_half = apples / people
        remaining_apples_half = apples % people

        return render_template('index.html', apples=apples, people=people,
                               apples_per_person=apples_per_person,
                               remaining_apples=remaining_apples,
                               apples_per_person_half=apples_per_person_half,
                               remaining_apples_half=remaining_apples_half)

    except ValueError:
        return render_template('index.html', error="Пожалуйста, введите корректные числа.")

if __name__ == '__main__':
    app.run(debug=True)
